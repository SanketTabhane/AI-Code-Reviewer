const { GoogleGenerativeAI } = require('@google/generative-ai');

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

async function generateContent(prompt, maxRetries = 3) {
    let lastError;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
            const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
            const result = await model.generateContent(prompt);
            const response = await result.response;
            return response.text();
        } catch (error) {
            lastError = error;

            // Check if it's a rate limit error (429)
            if (error.status === 429 || error.message?.includes('Too Many Requests')) {
                const retryAfter = error.message?.match(/retry in (\d+(?:\.\d+)?)/)?.[1] ||
                    (Math.pow(2, attempt) * 1000); // Exponential backoff

                if (attempt < maxRetries - 1) {
                    console.warn(`Rate limited. Retrying in ${retryAfter}ms... (Attempt ${attempt + 1}/${maxRetries})`);
                    await new Promise(resolve => setTimeout(resolve, retryAfter));
                    continue;
                }
            }

            console.error('Error generating content:', error);
            throw error;
        }
    }

    throw lastError;
}

module.exports = { generateContent };